/*
* Simple, 100% standard Java code
* No mavern, no gradle, nothing complex.
* No 3rd party libraries

[X] Uppercase
[X] Lowercase
[X] Digits
[X] Special characters
[   ] Password length

* Compile and create a JAR file.
* My code will be on Github

* TODO: min chars, min digits, eg. password must have 2 alphabetic letters
2 digits, and 1 special minimum.
*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PasswordGenerator extends JFrame
{
   // Constants:
   public static final String UPPERCASE_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   public static final String LOWERCASE_LETTERS = "abcdefghijklmnopqrstuvwxyz";
   public static final String DIGITS            = "0123456789";
   public static final String SPECIAL_CHARS     = ",.;:!";

   // GUI Components:
   JCheckBox uppercaseCheckBox                  = new JCheckBox ("Uppercase letters (A-Z)");
   JCheckBox lowercaseCheckBox                  = new JCheckBox ("Lowercase letters (a-z)");
   JCheckBox digitsCheckBox                     = new JCheckBox ("Digits (0-9)");
   JCheckBox specialCharsCheckBox               = new JCheckBox ("Special Chars: " + SPECIAL_CHARS);
   JButton   generatePassswordButton            = new JButton   ("Generate Password");
   JLabel    passwordLabel                      = new JLabel ();
   JButton   copyClipboardButton                = new JButton   ("Copy Clipboard");


   public PasswordGenerator ()
   {
      setLayout (new GridLayout (7, 1) );
      add (uppercaseCheckBox);
      add (lowercaseCheckBox);
      add (digitsCheckBox);
      add (specialCharsCheckBox);
      add (passwordLabel);
      add (generatePassswordButton);
      add (copyClipboardButton);

      generatePassswordButton.addActionListener (event -> generatePasssword () );


      setTitle    ("PasswordGenerator");
      setSize     (500, 500);
      setLocation (300, 100);
      setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      setVisible  (true);
   }

   private void generatePasssword ()
   {
      passwordLabel.setText ("password goes here");

      String passwordStr = "";
      int passwordLength = 15;

      for (int c = 0; c < passwordLength; c++)
      {
         if (uppercaseCheckBox.isSelected() == true)
         {
            int rand = (int) (Math.random() * UPPERCASE_LETTERS.length()); // 0 to 25.
            passwordStr += UPPERCASE_LETTERS.charAt (rand);
         }
      }

      passwordLabel.setText (passwordStr);

   }


   public static void main(String[] args)
   {
      new PasswordGenerator ();
   }
}